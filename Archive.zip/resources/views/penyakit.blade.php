@extends('layouts.app')

@section('content')
    <!-- BEGIN: Content -->
    <div class="content">
        @livewire('penyakits')

    </div>
    <!-- END: Content -->
@endsection
