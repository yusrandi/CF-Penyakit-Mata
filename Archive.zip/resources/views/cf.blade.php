@extends('layouts.app')

@section('content')
    <!-- BEGIN: Content -->
    <div class="content">
        @livewire('cfs')
    </div>
    <!-- END: Content -->
@endsection
