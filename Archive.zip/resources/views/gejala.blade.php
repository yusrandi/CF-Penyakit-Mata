@extends('layouts.app')

@section('content')
    <!-- BEGIN: Content -->
    <div class="content">
        @livewire('gejalas')

    </div>
    <!-- END: Content -->
@endsection
