@extends('layouts.app')

@section('content')
    <!-- BEGIN: Content -->
    <div class="content">
        @livewire('basis-pengetahuans')
    </div>
    <!-- END: Content -->
@endsection
