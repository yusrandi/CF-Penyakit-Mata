@extends('layouts.app')

@section('content')
    <!-- BEGIN: Content -->
    <div class="content">
        @livewire('laporans')

    </div>
    <!-- END: Content -->
@endsection
