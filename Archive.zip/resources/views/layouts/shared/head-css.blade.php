@livewireStyles
<link rel="stylesheet" href="dist/css/app.css" />
@yield('style')

<!-- BEGIN: CSS Assets-->
<!-- END: CSS Assets-->
