<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('laporans')->html();
} elseif ($_instance->childHasBeenRendered('Q73xr0B')) {
    $componentId = $_instance->getRenderedChildComponentId('Q73xr0B');
    $componentTag = $_instance->getRenderedChildComponentTagName('Q73xr0B');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Q73xr0B');
} else {
    $response = \Livewire\Livewire::mount('laporans');
    $html = $response->html();
    $_instance->logRenderedChild('Q73xr0B', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
    <!-- END: Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u7041471/public_html/mata/resources/views/laporan.blade.php ENDPATH**/ ?>