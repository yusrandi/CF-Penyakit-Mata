<!-- BEGIN: Top Menu -->
<nav class="top-nav">
    <ul>
        <li>
            <a href="<?php echo e(route('home')); ?>" class="top-menu <?php echo e(request()->is('home') ? 'top-menu--active' : ''); ?>">
                <div class="top-menu__icon"> <i data-feather="home"></i> </div>
                <div class="top-menu__title"> Dashboard </i>
                </div>
            </a>

        </li>
        <li>
            <a href="<?php echo e(route('penyakit')); ?>"
                class="top-menu <?php echo e(request()->is('penyakit') ? 'top-menu--active' : ''); ?>">
                <div class="top-menu__icon"> <i data-feather="box"></i> </div>
                <div class="top-menu__title"> Penyakit
                </div>
            </a>

        </li>
        <li>
            <a href="<?php echo e(route('gejala')); ?>"
                class="top-menu <?php echo e(request()->is('gejala') ? 'top-menu--active' : ''); ?>">
                <div class="top-menu__icon"> <i data-feather="activity"></i> </div>
                <div class="top-menu__title"> Gejala
                </div>
            </a>

        </li>
        <li>
            <a href="<?php echo e(route('cf')); ?>" class="top-menu <?php echo e(request()->is('cf') ? 'top-menu--active' : ''); ?>">
                <div class="top-menu__icon"> <i data-feather="activity"></i> </div>
                <div class="top-menu__title"> Nilai CF
                </div>
            </a>

        </li>
        <li>
            <a href="<?php echo e(route('basis')); ?>" class="top-menu <?php echo e(request()->is('basis') ? 'top-menu--active' : ''); ?>">
                <div class="top-menu__icon"> <i data-feather="activity"></i> </div>
                <div class="top-menu__title"> Basis Pengetahuan
                </div>
            </a>

        </li>

        <li>
            <a href="<?php echo e(route('diagnosa')); ?>"
                class="top-menu <?php echo e(request()->is('diagnosa') ? 'top-menu--active' : ''); ?>">
                <div class="top-menu__icon"> <i data-feather="activity"></i> </div>
                <div class="top-menu__title"> Diagnosa
                </div>
            </a>

        </li>
        <li>
            <a href="<?php echo e(route('laporan')); ?>"
                class="top-menu <?php echo e(request()->is('laporan') ? 'top-menu--active' : ''); ?>">
                <div class="top-menu__icon"> <i data-feather="align-right"></i> </div>
                <div class="top-menu__title"> Laporan
                </div>
            </a>

        </li>

    </ul>
</nav>
<!-- END: Top Menu -->
<?php /**PATH /home/u7041471/public_html/mata/resources/views/layouts/shared/top-nav.blade.php ENDPATH**/ ?>