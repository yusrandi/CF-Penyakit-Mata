<div class="p-5">
    <?php $__currentLoopData = $gejalas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mt-5">
            <label for="crud-form-1" class="form-label"><?php echo e($i->nama); ?></label>
            <select wire:model="gejala.<?php echo e($i->id); ?>" class="form-select sm:mr-2"
                aria-label="Default select example">
                <option>Silahkan pilih Nilai CF</option>
                <?php $__currentLoopData = $cfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($i->id . ',' . $item->nilai); ?>">
                        <?php echo e($item->nilai . ' , ' . $item->nama); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <?php if($errors->has('gejala.' . $i->id)): ?>
                <div class="text-theme-24 mt-2"><?php echo e($errors->first('gejala.' . $i->id)); ?></div>
            <?php endif; ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="text-right mt-5">
        <button wire:click="save" type="button" class="btn btn-primary w-24">Submit</button>
    </div>
</div>
<?php /**PATH /Users/userundie/Laravel Project/mata/resources/views/livewire/diagnosas.blade.php ENDPATH**/ ?>