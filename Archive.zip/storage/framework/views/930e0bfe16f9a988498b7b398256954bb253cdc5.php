<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="grid grid-cols-12 gap-6">
            <div class="col-span-12 xxl:col-span-9">
                <div class="grid grid-cols-12 gap-6">
                    <!-- BEGIN: Notification -->
                    <div class="col-span-12 mt-6 -mb-6 intro-y">
                        <div class="alert alert-dismissible show box bg-theme-26 text-white flex items-center mb-6"
                            role="alert">
                            <span>Selamat Datang di website Diagnosa Penyakit Mata</span>
                        </div>
                    </div>
                    <!-- BEGIN: Notification -->

                    <!-- BEGIN: Ads 1 -->
                    <div class="col-span-12 lg:col-span-6 mt-6">
                        <div class="ads-box box p-8 relative overflow-hidden bg-theme-17 intro-y">
                            <div class="ads-box__title w-full sm:w-72 text-white text-xl -mt-3">Jagalah Selalu Kesehatan Mata
                                anda</div>
                            <div
                                class="w-full sm:w-72 leading-relaxed text-white text-opacity-70 dark:text-gray-600 dark:text-opacity-100 mt-3">
                                Ayo, silahkan periksakan</div>
                            <a class="btn w-32 bg-white dark:bg-dark-2 dark:text-white mt-6 sm:mt-10"
                                href="<?php echo e(route('diagnosa')); ?>">Start
                                Now</a>
                            <img class="hidden sm:block absolute top-0 right-0 w-2/2 -mt-3 mr-2"
                                alt="Icewall Tailwind HTML Admin Template" src="images/mata1.png">
                        </div>
                    </div>
                    <!-- END: Ads 1 -->
                    <!-- BEGIN: Ads 2 -->
                    <div class="col-span-12 lg:col-span-6 mt-6">
                        <div class="ads-box box p-8 relative overflow-hidden intro-y">
                            <div class="ads-box__title w-full sm:w-52 text-theme-17 dark:text-white text-xl -mt-3">
                                Ajaklah teman anda <span class="font-medium">periksa</span> GRATIS!</div>
                            <div class="w-full sm:w-60 leading-relaxed text-gray-600 mt-2">anda berpeluang menjaga mata anda
                                dari penyakit mata</div>
                            <div class="w-48 relative mt-6 cursor-pointer tooltip" title="Copy referral link">
                                <input class="form-control" value="https://dashboard.in">
                                <i data-feather="copy" class="absolute right-0 top-0 bottom-0 my-auto mr-4 w-4 h-4"></i>
                            </div>
                            <img class="hidden sm:block absolute top-0 right-0 w-1/2 mt-1 -mr-12"
                                alt="Icewall Tailwind HTML Admin Template" src="images/mata2.png">
                        </div>
                    </div>
                    <!-- END: Ads 2 -->

                </div>
            </div>
            <div class="col-span-12 xxl:col-span-3">
                <div class="xxl:border-l border-theme-25 -mb-10 pb-10">
                    <div class="xxl:pl-6 grid grid-cols-12 gap-6">
                        <!-- BEGIN: Important Notes -->
                        <div class="col-span-12 md:col-span-6 xl:col-span-12 mt-3 xxl:mt-8">
                            <div class="intro-x flex items-center h-10">
                                <h2 class="text-lg font-medium truncate mr-auto">
                                    Important Notes
                                </h2>
                                <button data-carousel="important-notes" data-target="prev"
                                    class="tiny-slider-navigator btn px-2 border-gray-400 text-gray-700 dark:text-gray-300 mr-2">
                                    <i data-feather="chevron-left" class="w-4 h-4"></i> </button>
                                <button data-carousel="important-notes" data-target="next"
                                    class="tiny-slider-navigator btn px-2 border-gray-400 text-gray-700 dark:text-gray-300 mr-2">
                                    <i data-feather="chevron-right" class="w-4 h-4"></i> </button>
                            </div>
                            <div class="mt-5 intro-x">
                                <div class="box zoom-in">
                                    <div class="tiny-slider" id="important-notes">
                                        <div class="p-5">
                                            <div class="text-base font-medium truncate">Tentang Website ini</div>
                                            <div class="text-gray-500 mt-1">20 Hours ago</div>
                                            <div class="text-gray-600 text-justify mt-1">Sistem diagnosa penyakit mata ini
                                                merupakan sebuah sistem yang dapat membantu para penderita yang memiliki
                                                gejala penyakit mata untuk mendiagnosa penyakit mata yang diderita ,
                                            </div>
                                            <div class="text-gray-600 text-justify mt-1">Sistem ini menggunakan basis
                                                pengetahuan yang didapatkan dari pakar kesehatan mata
                                                yang dapat mendeteksi gejala-gejala dini penyakit mata yang diderita</div>
                                            <div class="font-medium flex mt-5">
                                                <button type="button" class="btn btn-secondary py-1 px-2">View
                                                    Notes</button>
                                                <button type="button"
                                                    class="btn btn-outline-secondary py-1 px-2 ml-auto ml-auto">Dismiss</button>
                                            </div>
                                        </div>
                                        <div class="p-5">
                                            <div class="text-base font-medium truncate">Survey Penyakit Mata</div>
                                            <div class="text-gray-500 mt-1">20 Hours ago</div>
                                            <div class="text-gray-600 text-justify mt-1">Menurut depkes tahun 2017 penyebab
                                                utama gangguan kebutaan di Indonesia adalah katarak (70.80%), sedangkan
                                                penyebab utama gangguan penglihatan adalah kelainan refraksi (10.15%).</div>
                                            <div class="text-gray-600 text-justify mt-1">Survei tersebut dilakukan pada
                                                penduduk diatas usia 50 tahun, sebanyak 15 provinsi itu sudah mencakup 65%
                                                orang Indonesia.</div>
                                            <div class="text-gray-600 text-justify mt-1">Penyakit mata sangat beragam dan
                                                cara menanganinya juga berbeda, tergantung dari penyebabnya. .</div>
                                            <div class="font-medium flex mt-5">
                                                <button type="button" class="btn btn-secondary py-1 px-2">View
                                                    Notes</button>
                                                <button type="button"
                                                    class="btn btn-outline-secondary py-1 px-2 ml-auto ml-auto">Dismiss</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- END: Important Notes -->
                        <!-- BEGIN: Recent Activities -->
                        
                        <!-- END: Recent Activities -->
                        <!-- BEGIN: Transactions -->
                        
                        <!-- END: Transactions -->
                        <!-- BEGIN: Schedules -->
                        
                        <!-- END: Schedules -->
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mata/resources/views/home.blade.php ENDPATH**/ ?>