<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cfs')->html();
} elseif ($_instance->childHasBeenRendered('gCkLw2U')) {
    $componentId = $_instance->getRenderedChildComponentId('gCkLw2U');
    $componentTag = $_instance->getRenderedChildComponentTagName('gCkLw2U');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gCkLw2U');
} else {
    $response = \Livewire\Livewire::mount('cfs');
    $html = $response->html();
    $_instance->logRenderedChild('gCkLw2U', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <!-- END: Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/userundie/LaravelProject/mata/resources/views/cf.blade.php ENDPATH**/ ?>