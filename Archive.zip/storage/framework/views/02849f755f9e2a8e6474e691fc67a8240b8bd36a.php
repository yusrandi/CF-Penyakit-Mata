<div>
    <div class="intro-y flex items-center mt-8">
        <h2 class="text-lg font-medium mr-auto">
            Data Gejala Penyakit
        </h2>
    </div>

    <div class="intro-y tab-content mt-5">
        <div id="dashboard" class="tab-pane active" role="tabpanel" aria-labelledby="dashboard-tab">
            <div class="grid grid-cols-12 gap-6">
                <!-- BEGIN: Top Categories -->
                <div class="intro-y box col-span-12 lg:col-span-8">
                    <div class="flex items-center p-5 border-b border-gray-200 dark:border-dark-5">
                        <h2 class="font-medium text-base mr-auto">
                            Tabel Gejala Penyakit
                        </h2>

                    </div>
                    <div class="p-5" id="basic-table">
                        <div class="preview">
                            <div class="overflow-x-auto">
                                <?php if($gejalas->count()): ?>
                                    <table class="table" nowrap>
                                        <thead>
                                            <tr>
                                                <th class="border-b-2 dark:border-dark-5 whitespace-nowrap">#</th>
                                                <th class="border-b-2 dark:border-dark-5 whitespace-nowrap">Kode
                                                    Penyakit
                                                </th>
                                                <th class="border-b-2 dark:border-dark-5 whitespace-nowrap">Nama
                                                    Penyakit
                                                </th>

                                                <th class="border-b-2 dark:border-dark-5 whitespace-nowrap text-right">
                                                    Aksi
                                                </th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $gejalas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($item->kode); ?></td>
                                                    <td><?php echo e($item->nama); ?></td>

                                                    <td class="text-right flex-center whitespace-nowrap">
                                                        <button wire:click="selectedItem(<?php echo e($item->id); ?>, 'update')"
                                                            type="button"
                                                            class="btn btn-success w-20 mr-2">Edit</button>
                                                        <button wire:click="selectedItem(<?php echo e($item->id); ?>, 'delete')"
                                                            wire:click="save" type="button"
                                                            class="btn btn-danger w-20">Delete</button>

                                                    </td>
                                                </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>

                                    </table>
                                <?php else: ?>
                                    There is no data yet
                                <?php endif; ?>


                            </div>
                        </div>

                    </div>

                </div>
                <!-- END: Top Categories -->
                <!-- BEGIN: Work In Progress -->
                <div class="intro-y box col-span-12 lg:col-span-4">

                    <div class="flex items-center p-5 border-b border-gray-200 dark:border-dark-5">
                        <h2 class="font-medium text-base mr-auto">
                            Form Tambah Gejala Penyakit
                        </h2>

                    </div>
                    <!-- BEGIN: Form Layout -->
                    <div class="p-5">
                        <div>
                            <label for="crud-form-1" class="form-label">Kode Gejala</label>
                            <input wire:model="kode" id="crud-form-1" type="text" class="form-control w-full"
                                placeholder="Kode Gejala">
                            <?php $__errorArgs = ['kode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="pristine-error text-theme-24 mt-2"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mt-3">
                            <label for="crud-form-3" class="form-label">Nama Gejala</label>
                            <input wire:model="nama" id="crud-form-3" type="text" class="form-control"
                                placeholder="Input Nama Gejala" aria-describedby="input-group-1">

                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="pristine-error text-theme-24 mt-2"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>



                        <div class="text-right mt-5">
                            <button wire:click="save" type="button" class="btn btn-primary w-24">Submit</button>
                        </div>
                    </div>
                    <!-- END: Form Layout -->

                </div>
                <!-- END: Work In Progress -->

            </div>
        </div>
    </div>

</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mata/resources/views/livewire/gejalas.blade.php ENDPATH**/ ?>