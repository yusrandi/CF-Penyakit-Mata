<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('gejalas')->html();
} elseif ($_instance->childHasBeenRendered('XtKz4FR')) {
    $componentId = $_instance->getRenderedChildComponentId('XtKz4FR');
    $componentTag = $_instance->getRenderedChildComponentTagName('XtKz4FR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XtKz4FR');
} else {
    $response = \Livewire\Livewire::mount('gejalas');
    $html = $response->html();
    $_instance->logRenderedChild('XtKz4FR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
    <!-- END: Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u7041471/public_html/mata/resources/views/gejala.blade.php ENDPATH**/ ?>