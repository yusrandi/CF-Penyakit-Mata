<div>
    <div class="intro-y flex items-center mt-8">
        <h2 class="text-lg font-medium mr-auto">
            Data Basis Pengetahuan
        </h2>
    </div>

    <div class="intro-y tab-content mt-5">
        <div id="dashboard" class="tab-pane active" role="tabpanel" aria-labelledby="dashboard-tab">
            <div class="grid grid-cols-12 gap-6">
                <!-- BEGIN: Top Categories -->
                <div class="intro-y box col-span-12 lg:col-span-9">
                    <div class="flex items-center p-5 border-b border-gray-200 dark:border-dark-5">
                        <h2 class="font-medium text-base mr-auto">
                            Tabel Basis Pengetahuan
                        </h2>

                    </div>
                    <div class="p-5" id="basic-table">
                        <div class="preview">
                            <div class="overflow-x-auto">
                                <?php if($basispengetahuans->count()): ?>
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="border-b-2 dark:border-dark-5 whitespace-nowrap">#</th>
                                                <th class="border-b-2 dark:border-dark-5 whitespace-nowrap">
                                                    Penyakit
                                                </th>
                                                <th class="border-b-2 dark:border-dark-5">
                                                    Gejala
                                                </th>
                                                <th class="border-b-2 dark:border-dark-5 whitespace-nowrap">CF Pakar
                                                </th>
                                                <th class="border-b-2 dark:border-dark-5 whitespace-nowrap">CF
                                                </th>
                                                <th class="border-b-2 dark:border-dark-5 whitespace-nowrap text-right">
                                                    Aksi
                                                </th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php $__currentLoopData = $basispengetahuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($item->penyakit->nama); ?></td>
                                                    <td><?php echo e($item->gejala->nama); ?></td>
                                                    <td><?php echo e($item->cf->nama); ?></td>
                                                    <td><?php echo e($item->cf->nilai); ?></td>
                                                    <td class="text-right whitespace-nowrap">
                                                        <button wire:click="selectedItem(<?php echo e($item->id); ?>, 'update')"
                                                            type="button"
                                                            class="btn btn-success w-15 mr-2">Edit</button>
                                                        <button wire:click="selectedItem(<?php echo e($item->id); ?>, 'delete')"
                                                            wire:click="save" type="button"
                                                            class="btn btn-danger w-15">Delete</button>

                                                    </td>
                                                </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>

                                    </table>
                                <?php else: ?>
                                    There is no data yet
                                <?php endif; ?>


                            </div>
                        </div>

                    </div>

                </div>
                <!-- END: Top Categories -->
                <!-- BEGIN: Work In Progress -->
                <div class="intro-y box col-span-12 lg:col-span-3">

                    <div class="flex items-center p-5 border-b border-gray-200 dark:border-dark-5">
                        <h2 class="font-medium text-base mr-auto">
                            Form Tambah Basis Pengetahuan
                        </h2>

                    </div>
                    <!-- BEGIN: Form Layout -->
                    <div class="p-5">

                        <div>
                            <label for="crud-form-1" class="form-label">Pilih Penyakit</label>
                            <select wire:model="penyakit_id" class="form-select mt-2 sm:mr-2"
                                aria-label="Default select example">
                                <option>Silahkan pilih penyakit</option>
                                <?php $__currentLoopData = $penyakits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                        <div class="mt-3">
                            <label for="crud-form-1" class="form-label">Pilih Gejala Penyakit</label>
                            <select wire:model="gejala_id" class="form-select mt-2 sm:mr-2"
                                aria-label="Default select example">
                                <option>Silahkan pilih Gejala</option>
                                <?php $__currentLoopData = $gejalas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mt-3">
                            <label for="crud-form-1" class="form-label">Pilih Nilai CF</label>
                            <select wire:model="cf_id" class="form-select mt-2 sm:mr-2"
                                aria-label="Default select example">
                                <option>Silahkan pilih Nilai CF</option>
                                <?php $__currentLoopData = $cfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>">
                                        <?php echo e($item->nilai . ' , ' . $item->nama); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>


                        <div class="text-right mt-5">
                            <button wire:click="save" type="button" class="btn btn-primary w-24">Submit</button>
                        </div>
                    </div>


                </div>
                <!-- END: Form Layout -->

            </div>
            <!-- END: Work In Progress -->

        </div>
    </div>
</div>

</div>
<?php /**PATH /Users/userundie/LaravelProject/mata/resources/views/livewire/basis-pengetahuans.blade.php ENDPATH**/ ?>