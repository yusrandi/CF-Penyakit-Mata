<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('penyakits')->html();
} elseif ($_instance->childHasBeenRendered('FB1UVS8')) {
    $componentId = $_instance->getRenderedChildComponentId('FB1UVS8');
    $componentTag = $_instance->getRenderedChildComponentTagName('FB1UVS8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FB1UVS8');
} else {
    $response = \Livewire\Livewire::mount('penyakits');
    $html = $response->html();
    $_instance->logRenderedChild('FB1UVS8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
    <!-- END: Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/userundie/Laravel Project/mata/resources/views/penyakit.blade.php ENDPATH**/ ?>