<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('gejalas')->html();
} elseif ($_instance->childHasBeenRendered('JZYfzOd')) {
    $componentId = $_instance->getRenderedChildComponentId('JZYfzOd');
    $componentTag = $_instance->getRenderedChildComponentTagName('JZYfzOd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JZYfzOd');
} else {
    $response = \Livewire\Livewire::mount('gejalas');
    $html = $response->html();
    $_instance->logRenderedChild('JZYfzOd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
    <!-- END: Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mata/resources/views/gejala.blade.php ENDPATH**/ ?>