<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('basis-pengetahuans')->html();
} elseif ($_instance->childHasBeenRendered('UKn8I1u')) {
    $componentId = $_instance->getRenderedChildComponentId('UKn8I1u');
    $componentTag = $_instance->getRenderedChildComponentTagName('UKn8I1u');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UKn8I1u');
} else {
    $response = \Livewire\Livewire::mount('basis-pengetahuans');
    $html = $response->html();
    $_instance->logRenderedChild('UKn8I1u', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <!-- END: Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/userundie/LaravelProject/mata/resources/views/basispengetahuan.blade.php ENDPATH**/ ?>