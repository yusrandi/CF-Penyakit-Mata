<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content">
        <div>
            <div class="intro-y flex items-center mt-8">
                <h2 class="text-lg font-medium mr-auto">
                    Diagnosa Penyakit
                </h2>
            </div>

            <div class="intro-y tab-content mt-5">
                <div id="dashboard" class="tab-pane active" role="tabpanel" aria-labelledby="dashboard-tab">

                    <div class="grid grid-cols-12 gap-12">

                        <!-- BEGIN: Work In Progress -->
                        <div class="intro-y box col-span-12 lg:col-span-12 mr-2">

                            <div class="flex items-center p-5 border-b border-gray-200 dark:border-dark-5">
                                <h2 class="font-medium text-base mr-auto">
                                    Form Diagnosa

                                </h2>

                            </div>

                            


                            <form action="<?php echo e(route('diagnosa.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <!-- BEGIN: Form Layout -->
                                <div class="p-5">
                                    <?php $__currentLoopData = $gejalas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mt-5">
                                            <label for="crud-form-1" class="form-label"><?php echo e($i->nama); ?></label>
                                            <select class="form-select sm:mr-2" aria-label="Default select example"
                                                name="<?php echo e($i->kode); ?>">
                                                <option value="">Silahkan pilih Nilai CF</option>
                                                <?php $__currentLoopData = $cfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($i->id . ',' . $item->nilai); ?>"
                                                        <?php echo e(old($i->kode) == $i->id . ',' . $item->nilai ? 'selected' : ''); ?>>
                                                        <?php echo e($item->nilai . ' , ' . $item->nama); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>

                                            <?php if($errors->has($i->kode)): ?>
                                                <div class="text-theme-24 mt-2"> This field is required
                                                </div>
                                            <?php endif; ?>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="mt-10">
                                        <button type="submit" class="btn btn-primary w-24">Submit</button>
                                    </div>

                            </form>
                        </div>
                        <!-- END: Form Layout -->

                    </div>
                    <!-- END: Work In Progress -->


                </div>

            </div>
        </div>

    </div>

    </div>
    <!-- END: Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/userundie/Laravel Project/mata/resources/views/diagnosa.blade.php ENDPATH**/ ?>