<?php echo \Livewire\Livewire::styles(); ?>

<link rel="stylesheet" href="dist/css/app.css" />
<?php echo $__env->yieldContent('style'); ?>

<!-- BEGIN: CSS Assets-->
<!-- END: CSS Assets-->
<?php /**PATH /Users/userundie/Laravel Project/mata/resources/views/layouts/shared/head-css.blade.php ENDPATH**/ ?>