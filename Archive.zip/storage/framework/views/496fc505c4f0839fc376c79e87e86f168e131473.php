<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content">
        <div>
            <div class="intro-y flex items-center mt-8">
                <h2 class="text-lg font-medium mr-auto">
                    Diagnosa Penyakit
                </h2>
            </div>

            <div class="intro-y tab-content mt-5">
                <div id="dashboard" class="tab-pane active" role="tabpanel" aria-labelledby="dashboard-tab">

                    <div class="grid grid-cols-12 gap-12">

                        <!-- BEGIN: Work In Progress -->
                        <div class="intro-y box col-span-12 lg:col-span-12 mr-2">

                            <div class="flex items-center p-5 border-b border-gray-200 dark:border-dark-5">
                                <h2 class="font-medium text-base mr-auto">
                                    Form Diagnosa
                                </h2>

                            </div>


                            <form action="<?php echo e(route('diagnosa.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <!-- BEGIN: Form Layout -->
                                <div class="p-5">
                                    <?php $__currentLoopData = $gejalas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="mt-10">
                                            <label for="crud-form-1"
                                                class="form-label"><?php echo e($index + 1 . '. ' . $i->nama); ?></label>
                                            <div class="mt-3">
                                                <div class="flex flex-col sm:flex-row mt-2">
                                                    <?php $__currentLoopData = $cfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="form-check mr-2">
                                                            <input id="<?php echo e('radio-' . $index . '-' . $in); ?>"
                                                                name="<?php echo e('radio-' . $index); ?>" class="form-check-input"
                                                                type="radio" name="horizontal_radio_button"
                                                                value="<?php echo e($item->nilai); ?>">
                                                            <label class="form-check-label"
                                                                for="<?php echo e('radio-' . $index . '-' . $in); ?>"><?php echo e($item->nama); ?></label>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="mt-10">
                                        <button type="submit" class="btn btn-primary w-24">Submit</button>
                                    </div>

                            </form>
                        </div>
                        <!-- END: Form Layout -->

                    </div>
                    <!-- END: Work In Progress -->


                </div>

            </div>
        </div>

    </div>

    </div>
    <!-- END: Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/mata/resources/views/diagnosa.blade.php ENDPATH**/ ?>