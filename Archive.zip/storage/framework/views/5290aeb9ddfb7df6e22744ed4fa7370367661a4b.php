<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('basis-pengetahuans')->html();
} elseif ($_instance->childHasBeenRendered('HIxz84X')) {
    $componentId = $_instance->getRenderedChildComponentId('HIxz84X');
    $componentTag = $_instance->getRenderedChildComponentTagName('HIxz84X');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HIxz84X');
} else {
    $response = \Livewire\Livewire::mount('basis-pengetahuans');
    $html = $response->html();
    $_instance->logRenderedChild('HIxz84X', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    <!-- END: Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/userundie/Laravel Project/mata/resources/views/basispengetahuan.blade.php ENDPATH**/ ?>