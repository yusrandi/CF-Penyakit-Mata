<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('gejalas')->html();
} elseif ($_instance->childHasBeenRendered('9qm3Kaa')) {
    $componentId = $_instance->getRenderedChildComponentId('9qm3Kaa');
    $componentTag = $_instance->getRenderedChildComponentTagName('9qm3Kaa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9qm3Kaa');
} else {
    $response = \Livewire\Livewire::mount('gejalas');
    $html = $response->html();
    $_instance->logRenderedChild('9qm3Kaa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
    <!-- END: Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/userundie/LaravelProject/mata/resources/views/gejala.blade.php ENDPATH**/ ?>