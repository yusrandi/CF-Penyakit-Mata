<?php

namespace App\Http\Controllers;

use App\Models\Cf;
use Illuminate\Http\Request;

class CfController extends Controller
{
   
    public function index()
    {
        //
        return view('cf');
    }

    
}
