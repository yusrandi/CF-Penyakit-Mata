<?php return array (
  'basis-pengetahuans' => 'App\\Http\\Livewire\\BasisPengetahuans',
  'cfs' => 'App\\Http\\Livewire\\Cfs',
  'diagnosas' => 'App\\Http\\Livewire\\Diagnosas',
  'gejalas' => 'App\\Http\\Livewire\\Gejalas',
  'laporans' => 'App\\Http\\Livewire\\Laporans',
  'penyakits' => 'App\\Http\\Livewire\\Penyakits',
);